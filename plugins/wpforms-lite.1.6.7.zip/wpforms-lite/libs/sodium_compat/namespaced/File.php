<?php
namespace ParagonIE\Sodium;

class File extends \ParagonIE_Sodium_File
{

}
